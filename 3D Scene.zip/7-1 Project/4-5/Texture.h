#pragma once
#include <string>

class Texture_2D
{
public:
	Texture_2D(const std::string& texture_filePath, const std::string& name /*= "m_texture"*/, unsigned int format, unsigned internalFormat);
	
	~Texture_2D()
	{

	}

	void unbind(unsigned int slot /*= 0*/);
	void bind(unsigned int slot /*= 0*/);


private:
	unsigned int m_rendererID;
};