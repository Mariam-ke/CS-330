#include "Texture.h"
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

#include <iostream>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"




	Texture_2D::Texture_2D(const std::string& texture_filePath, const std::string& name /*= "m_texture"*/, unsigned int format, unsigned internalFormat)
	{
		int m_width = 0, m_hieght = 0, m_BPP = 0;
		unsigned char* tex_data = nullptr;
		if (texture_filePath.find("png") != std::string::npos || texture_filePath.find(".png") != std::string::npos)
		{
			 stbi_set_flip_vertically_on_load(1);
		}

		tex_data = stbi_load(texture_filePath.c_str(), &m_width, &m_hieght, &m_BPP, 4);//TODO chek the meaning of bits per pixel

		if (!tex_data)
		{
			std::cerr << "[ERROR:] failed to load texture:  " << name << std::endl;
		}

		glGenTextures(1, &m_rendererID);
		glBindTexture(GL_TEXTURE_2D, m_rendererID);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		glTexImage2D(GL_TEXTURE_2D, 0, internalFormat, m_width, m_hieght, 0, format, GL_UNSIGNED_BYTE, tex_data);
		glBindTexture(GL_TEXTURE_2D, 0);


		if (tex_data)
		{
			stbi_image_free(tex_data);
		}

	}


	void Texture_2D::bind(unsigned int slot /*= 0*/)
	{
		glActiveTexture((GL_TEXTURE0 + slot));
		glBindTexture(GL_TEXTURE_2D, m_rendererID);
	}

	void Texture_2D::unbind(unsigned int slot /*= 0*/)
	{
		glActiveTexture((GL_TEXTURE0 + slot));
		glBindTexture(GL_TEXTURE_2D, 0);
	}

	